package rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@Path("/calculadora")

public class calculadora {
	
	@GET
	@Produces("text/plain")

public String somar(@QueryParam("valor1") String valor1, @QueryParam("valor2") String valor2) {
		
		int soma;
		
		soma = Integer.parseInt(valor1, 2) + Integer.parseInt(valor2, 2);
		
		return ("Soma de " + valor1 + " + " + valor2 + " = " + Integer.toBinaryString(soma));
	}
}
